// create a class
var Grocery = /** @class */ (function () {
    function Grocery(n, q, p) {
        this.name = n;
        this.quantity = q;
        this.price = p;
    }
    Grocery.prototype.format = function () {
        return "".concat(this.name, " ").concat(this.quantity, " -> ").concat(this.price);
    };
    return Grocery;
}());
var list_of_items = [];
var arr = [];
var add_btn = document.getElementById('add');
add_btn === null || add_btn === void 0 ? void 0 : add_btn.addEventListener('click', function (event) {
    var el_name = document.getElementById("name");
    var el_quantity = document.getElementById("quantity");
    var el_price = document.getElementById("price");
    var name_value = el_name === null || el_name === void 0 ? void 0 : el_name.value;
    var quantity_value = parseInt(el_quantity === null || el_quantity === void 0 ? void 0 : el_quantity.value);
    var price_value = parseInt(el_price === null || el_price === void 0 ? void 0 : el_price.value);
    var obj = new Grocery(name_value, quantity_value, price_value);
    arr.push(obj);
    add_grocery();
});
function add_grocery() {
    var ele = document.getElementById("app");
    ele.textContent = '';
    var id = 0;
    arr.forEach(function (e) {
        var p = document.createElement("p");
        p.textContent = e.format();
        var del = document.createElement("button");
        del.setAttribute('id', id.toString());
        del.setAttribute('onclick', 'delete_row(this.id)');
        del.textContent = 'Delete';
        ele.appendChild(p);
        ele.appendChild(del);
        id++;
    });
}
function delete_row(id) {
    console.log(id);
    arr.splice(id, 1);
    add_grocery();
}
