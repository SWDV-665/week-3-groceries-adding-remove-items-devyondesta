// create a class
class Grocery {
    name: string;
    quantity: number;
    price: number;

    constructor(n: string, q: number, p: number){
        this.name = n;
        this.quantity = q;
        this.price = p;
    }

    format() {
        return `${this.name} ${this.quantity} -> ${this.price}`;
    }

}

var list_of_items = [];
const arr: Grocery[] = [];
const add_btn = document.getElementById('add') as HTMLInputElement;

add_btn?.addEventListener('click', function (event) {
    const el_name = document.getElementById("name") as HTMLInputElement;
    const el_quantity = document.getElementById("quantity") as HTMLInputElement;
    const el_price = document.getElementById("price") as HTMLInputElement;
    const name_value = el_name?.value;
    const quantity_value = parseInt(el_quantity?.value);
    const price_value = parseInt(el_price?.value);
    var obj = new Grocery(name_value, quantity_value, price_value);
    arr.push(obj);
    
    add_grocery();
        
});

  
function add_grocery(){
    var ele = document.getElementById("app")!;
    ele.textContent = '';
    var id = 0;
    arr.forEach(function (e) {
        var p = document.createElement("p");
        p.textContent = e.format();
        var del = document.createElement("button");
        del.setAttribute('id', id.toString());
        del.setAttribute('onclick', 'delete_row(this.id)');
        del.textContent = 'Delete'        
        ele.appendChild(p);
        ele.appendChild(del);
        id++;
    });
}

function delete_row(id){
    console.log(id);
    arr.splice(id, 1);
    add_grocery();
}